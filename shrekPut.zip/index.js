const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");

const ddbClient = new DynamoDBClient({ region: 'us-east-1' });

exports.handler = async function (event) {
  const params = {
    TableName: 'Team-Sequioa',
    Item: {
      Rank: { S: '1' },
      PlayerName: { S: 'John Doe' },
      HighScore: { N: '100' },
    }
  };

  try {
    const command = new PutItemCommand(params);
    const data = await ddbClient.send(command);
    console.log('Success', data);
    return {
      statusCode: 200,
      body: 'Item successfully added to DynamoDB'
    };
  } catch (err) {
    console.log('Error', err);
    return {
      statusCode: 500,
      body: 'Error adding item to DynamoDB: ' + err.message
    };
  }
};